# DogSeeker

Serverless app over AWS.

API Gateway
DynamoDB
Lambda
